
import { Supplier, Order, PurchaseHistory, CustomerFeedback, Urgency, SupplierMetrics, SimulationConfig } from './types';
import { differenceInDays, isBefore, isSameDay, parseISO } from 'date-fns';

export const mockSuppliers: Supplier[] = [
  {
    id: 's1',
    name: 'Supplier C',
    contact: 'contact@globalprecision.com',
    capabilities: ['CNC Machining', 'Lathe', 'Milling'],
    maxCapacity: 5000,
    typicalSpeedDays: 5,
    priceRange: { min: 45, max: 120 },
    urgencyLevel: Urgency.PLANNED,
    promisedDeliveryDate: '2024-03-01T09:00:00',
    actualDeliveryDate: '2024-03-01T10:30:00'
  },
  {
    id: 's2',
    name: 'Supplier D',
    contact: 'sales@apexsupply.net',
    capabilities: ['Fasteners', 'Hardware', 'Bulk Supply'],
    maxCapacity: 10000,
    typicalSpeedDays: 2,
    priceRange: { min: 10, max: 35 },
    urgencyLevel: Urgency.IMMEDIATE,
    promisedDeliveryDate: '2024-03-05T14:00:00',
    actualDeliveryDate: '2024-03-06T11:00:00'
  },
  {
    id: 's3',
    name: 'Supplier B',
    contact: 'support@techflow.io',
    capabilities: ['PCB Assembly', 'SMT', 'Testing'],
    maxCapacity: 2000,
    typicalSpeedDays: 10,
    priceRange: { min: 150, max: 450 },
    urgencyLevel: Urgency.SCHEDULED,
    promisedDeliveryDate: '2024-03-15T10:00:00',
    actualDeliveryDate: '2024-03-15T09:45:00'
  },
  {
    id: 's4',
    name: 'Supplier E',
    contact: 'info@ecomat.org',
    capabilities: ['Recycled Plastics', 'Bio-polymers'],
    maxCapacity: 8000,
    typicalSpeedDays: 7,
    priceRange: { min: 25, max: 65 },
    urgencyLevel: Urgency.PLANNED,
    promisedDeliveryDate: '2024-03-20T16:00:00',
    actualDeliveryDate: '2024-03-22T13:00:00'
  },
  {
    id: 's5',
    name: 'Supplier A',
    contact: 'ops@titanforge.com',
    capabilities: ['Forging', 'Heat Treatment', 'Titanium Alloys'],
    maxCapacity: 1500,
    typicalSpeedDays: 15,
    priceRange: { min: 500, max: 1200 },
    urgencyLevel: Urgency.SCHEDULED,
    promisedDeliveryDate: '2024-03-25T11:00:00',
    actualDeliveryDate: '2024-03-25T11:00:00'
  }
];

export const mockOrders: Order[] = [
  { id: 'o1', supplierId: 's1', quantity: 100, urgency: Urgency.PLANNED, requestedDate: '2024-03-01', status: 'DELIVERED' },
  { id: 'o2', supplierId: 's1', quantity: 200, urgency: Urgency.IMMEDIATE, requestedDate: '2024-03-05', status: 'DELIVERED' },
  { id: 'o3', supplierId: 's2', quantity: 5000, urgency: Urgency.SCHEDULED, requestedDate: '2024-03-10', status: 'DELIVERED' },
  { id: 'o4', supplierId: 's3', quantity: 50, urgency: Urgency.PLANNED, requestedDate: '2024-03-15', status: 'DELIVERED' },
  { id: 'o5', supplierId: 's4', quantity: 1000, urgency: Urgency.IMMEDIATE, requestedDate: '2024-03-20', status: 'DELIVERED' },
  { id: 'o6', supplierId: 's5', quantity: 20, urgency: Urgency.SCHEDULED, requestedDate: '2024-03-25', status: 'DELIVERED' },
  { id: 'o7', supplierId: 's1', quantity: 150, urgency: Urgency.PLANNED, requestedDate: '2024-04-01', status: 'DELIVERED' },
  { id: 'o8', supplierId: 's2', quantity: 3000, urgency: Urgency.IMMEDIATE, requestedDate: '2024-04-05', status: 'DELIVERED' },
  { id: 'o9', supplierId: 's3', quantity: 100, urgency: Urgency.SCHEDULED, requestedDate: '2024-04-10', status: 'DELIVERED' },
  { id: 'o10', supplierId: 's4', quantity: 500, urgency: Urgency.PLANNED, requestedDate: '2024-04-15', status: 'DELIVERED' },
];

export const mockHistory: PurchaseHistory[] = [
  { id: 'h1', orderId: 'o1', supplierId: 's1', proposedDeliveryDate: '2024-03-01', actualDeliveryDate: '2024-03-01', priceAgreed: 100, pricePaid: 100 },
  { id: 'h2', orderId: 'o2', supplierId: 's1', proposedDeliveryDate: '2024-03-05', actualDeliveryDate: '2024-03-06', priceAgreed: 110, pricePaid: 115 },
  { id: 'h3', orderId: 'o3', supplierId: 's2', proposedDeliveryDate: '2024-03-10', actualDeliveryDate: '2024-03-09', priceAgreed: 20, pricePaid: 20 },
  { id: 'h4', orderId: 'o4', supplierId: 's3', proposedDeliveryDate: '2024-03-15', actualDeliveryDate: '2024-03-15', priceAgreed: 300, pricePaid: 300 },
  { id: 'h5', orderId: 'o5', supplierId: 's4', proposedDeliveryDate: '2024-03-20', actualDeliveryDate: '2024-03-22', priceAgreed: 45, pricePaid: 50 },
  { id: 'h6', orderId: 'o6', supplierId: 's5', proposedDeliveryDate: '2024-03-25', actualDeliveryDate: '2024-03-25', priceAgreed: 800, pricePaid: 800 },
  { id: 'h7', orderId: 'o7', supplierId: 's1', proposedDeliveryDate: '2024-04-01', actualDeliveryDate: '2024-04-01', priceAgreed: 100, pricePaid: 100 },
  { id: 'h8', orderId: 'o8', supplierId: 's2', proposedDeliveryDate: '2024-04-05', actualDeliveryDate: '2024-04-07', priceAgreed: 22, pricePaid: 25 },
  { id: 'h9', orderId: 'o9', supplierId: 's3', proposedDeliveryDate: '2024-04-10', actualDeliveryDate: '2024-04-10', priceAgreed: 310, pricePaid: 310 },
  { id: 'h10', orderId: 'o10', supplierId: 's4', proposedDeliveryDate: '2024-04-15', actualDeliveryDate: '2024-04-14', priceAgreed: 48, pricePaid: 48 },
];

export const mockFeedback: CustomerFeedback[] = [
  { id: 'f1', orderId: 'o1', supplierId: 's1', qualityRating: 5, returnedItems: 0, totalItems: 100 },
  { id: 'f2', orderId: 'o2', supplierId: 's1', qualityRating: 4, returnedItems: 2, totalItems: 200 },
  { id: 'f3', orderId: 'o3', supplierId: 's2', qualityRating: 5, returnedItems: 0, totalItems: 5000 },
  { id: 'f4', orderId: 'o4', supplierId: 's3', qualityRating: 3, returnedItems: 5, totalItems: 50 },
  { id: 'f5', orderId: 'o5', supplierId: 's4', qualityRating: 4, returnedItems: 10, totalItems: 1000 },
  { id: 'f6', orderId: 'o6', supplierId: 's5', qualityRating: 5, returnedItems: 0, totalItems: 20 },
  { id: 'f7', orderId: 'o7', supplierId: 's1', qualityRating: 5, returnedItems: 0, totalItems: 150 },
  { id: 'f8', orderId: 'o8', supplierId: 's2', qualityRating: 4, returnedItems: 50, totalItems: 3000 },
  { id: 'f9', orderId: 'o9', supplierId: 's3', qualityRating: 4, returnedItems: 1, totalItems: 100 },
  { id: 'f10', orderId: 'o10', supplierId: 's4', qualityRating: 5, returnedItems: 0, totalItems: 500 },
];

export const calculateMetrics = (
  supplier: Supplier,
  orders: Order[],
  history: PurchaseHistory[],
  feedback: CustomerFeedback[],
  config: SimulationConfig
): SupplierMetrics => {
  const supplierOrders = orders.filter(o => o.supplierId === supplier.id);
  const supplierHistory = history.filter(h => h.supplierId === supplier.id);
  const supplierFeedback = feedback.filter(f => f.supplierId === supplier.id);

  // On-Time Delivery %
  const onTimeOrders = supplierHistory.filter(h => {
    const actual = parseISO(h.actualDeliveryDate);
    const proposed = parseISO(h.proposedDeliveryDate);
    return isBefore(actual, proposed) || isSameDay(actual, proposed);
  }).length;
  const onTimeDeliveryPercent = supplierHistory.length > 0 ? (onTimeOrders / supplierHistory.length) * 100 : 0;

  // Quality Score (0-100)
  const avgRating = supplierFeedback.length > 0 ? supplierFeedback.reduce((acc, f) => acc + f.qualityRating, 0) / supplierFeedback.length : 0;
  const qualityScore = (avgRating / 5) * 100;

  // Rejection Rate %
  const totalItems = supplierFeedback.reduce((acc, f) => acc + f.totalItems, 0);
  const returnedItems = supplierFeedback.reduce((acc, f) => acc + f.returnedItems, 0);
  const rejectionRate = totalItems > 0 ? (returnedItems / totalItems) * 100 : 0;

  // Price Efficiency Score
  // Formula: 100 - ((actual_price - min_price)/(max_price - min_price) * 100)
  const avgActualPrice = supplierHistory.length > 0 ? supplierHistory.reduce((acc, h) => acc + h.pricePaid, 0) / supplierHistory.length : 0;
  const { min, max } = supplier.priceRange;
  const priceEfficiency = max > min ? 100 - ((avgActualPrice - min) / (max - min) * 100) : 100;

  // Final Score based on Urgency
  let finalScore = 0;
  const { urgency } = config;

  if (urgency === Urgency.IMMEDIATE) {
    // 0.5 * OnTimeDeliveryPercent + 0.3 * QualityScore - 0.2 * RejectionRate
    finalScore = 0.5 * onTimeDeliveryPercent + 0.3 * qualityScore - 0.2 * rejectionRate;
  } else if (urgency === Urgency.PLANNED) {
    // 0.4 * QualityScore + 0.3 * OnTimeDeliveryPercent - 0.1 * RejectionRate + 0.2 * PriceEfficiency
    finalScore = 0.4 * qualityScore + 0.3 * onTimeDeliveryPercent - 0.1 * rejectionRate + 0.2 * priceEfficiency;
  } else if (urgency === Urgency.SCHEDULED) {
    // 0.3 * QualityScore + 0.3 * OnTimeDeliveryPercent - 0.1 * RejectionRate + 0.3 * PriceEfficiency
    finalScore = 0.3 * qualityScore + 0.3 * onTimeDeliveryPercent - 0.1 * rejectionRate + 0.3 * priceEfficiency;
  }

  return {
    onTimeDeliveryPercent,
    qualityScore,
    rejectionRate,
    priceEfficiency,
    rating: avgRating,
    finalScore: Math.max(0, Math.min(100, finalScore)),
    rank: 0 // Will be calculated after sorting
  };
};

export const getRankedSuppliers = (
  suppliers: Supplier[],
  orders: Order[],
  history: PurchaseHistory[],
  feedback: CustomerFeedback[],
  config: SimulationConfig
) => {
  const ranked = suppliers.map(s => ({
    ...s,
    metrics: calculateMetrics(s, orders, history, feedback, config)
  }));

  ranked.sort((a, b) => b.metrics.finalScore - a.metrics.finalScore);

  return ranked.map((s, index) => ({
    ...s,
    metrics: {
      ...s.metrics,
      rank: index + 1
    }
  }));
};


export enum Urgency {
  IMMEDIATE = 'IMMEDIATE',
  PLANNED = 'PLANNED',
  SCHEDULED = 'SCHEDULED'
}

export interface Supplier {
  id: string;
  name: string;
  contact: string;
  capabilities: string[];
  maxCapacity: number;
  typicalSpeedDays: number;
  priceRange: { min: number; max: number };
  urgencyLevel?: Urgency;
  promisedDeliveryDate?: string;
  actualDeliveryDate?: string;
}

export interface Order {
  id: string;
  supplierId: string;
  quantity: number;
  urgency: Urgency;
  requestedDate: string;
  status: 'PENDING' | 'DELIVERED' | 'CANCELLED';
}

export interface PurchaseHistory {
  id: string;
  orderId: string;
  supplierId: string;
  proposedDeliveryDate: string;
  actualDeliveryDate: string;
  priceAgreed: number;
  pricePaid: number;
}

export interface CustomerFeedback {
  id: string;
  orderId: string;
  supplierId: string;
  qualityRating: number; // 1-5
  returnedItems: number;
  totalItems: number;
}

export interface SupplierMetrics {
  onTimeDeliveryPercent: number;
  qualityScore: number;
  rejectionRate: number;
  priceEfficiency: number;
  rating: number;
  finalScore: number;
  rank: number;
}

export interface SimulationConfig {
  urgency: Urgency;
  weights: {
    speed: number;
    quality: number;
    cost: number;
  };
  thresholds: {
    onTime: number;
    rejection: number;
    priceDeviation: number;
  };
}


import React, { useState, useMemo, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  ShoppingCart, 
  History, 
  MessageSquare, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle,
  Search,
  Filter,
  Download,
  Settings2,
  ChevronRight,
  Star,
  Zap,
  Clock,
  Calendar,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  X
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell,
  AreaChart,
  Area
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, parseISO } from 'date-fns';

import { 
  Supplier, 
  Order, 
  PurchaseHistory, 
  CustomerFeedback, 
  Urgency, 
  SimulationConfig,
  SupplierMetrics 
} from './types';
import { 
  mockSuppliers, 
  mockOrders, 
  mockHistory, 
  mockFeedback, 
  getRankedSuppliers 
} from './data';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Components ---

const KpiCard = ({ title, value, icon: Icon, trend, color }: { 
  title: string; 
  value: string | number; 
  icon: any; 
  trend?: { val: string; positive: boolean };
  color: string;
}) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
    <div className="flex justify-between items-start mb-4">
      <div className={cn("p-3 rounded-xl", color)}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      {trend && (
        <div className={cn(
          "flex items-center gap-1 text-sm font-medium px-2 py-1 rounded-full",
          trend.positive ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
        )}>
          {trend.positive ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
          {trend.val}
        </div>
      )}
    </div>
    <h3 className="text-slate-500 text-sm font-medium mb-1">{title}</h3>
    <p className="text-2xl font-bold text-slate-900">{value}</p>
  </div>
);

const SectionHeader = ({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) => (
  <div className="flex justify-between items-end mb-6">
    <div>
      <h2 className="text-xl font-bold text-slate-900">{title}</h2>
      {subtitle && <p className="text-slate-500 text-sm">{subtitle}</p>}
    </div>
    {action}
  </div>
);

const RecommendationBadge = ({ rank }: { rank: number }) => {
  if (rank === 1) return <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-xs font-bold rounded-full border border-emerald-200 uppercase tracking-wider">Highly Recommended</span>;
  if (rank <= 3) return <span className="px-3 py-1 bg-amber-100 text-amber-700 text-xs font-bold rounded-full border border-amber-200 uppercase tracking-wider">Acceptable</span>;
  return <span className="px-3 py-1 bg-rose-100 text-rose-700 text-xs font-bold rounded-full border border-rose-200 uppercase tracking-wider">Risky</span>;
};

const MetricBar = ({ label, value, color, suffix = '%' }: { label: string; value: number; color: string; suffix?: string }) => (
  <div className="mb-3 last:mb-0">
    <div className="flex justify-between text-xs font-medium mb-1">
      <span className="text-slate-500">{label}</span>
      <span className="text-slate-900">{value.toFixed(1)}{suffix}</span>
    </div>
    <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
      <motion.div 
        initial={{ width: 0 }}
        animate={{ width: `${Math.min(100, Math.max(0, value))}%` }}
        className={cn("h-full rounded-full", color)}
      />
    </div>
  </div>
);

const RatingStars = ({ rating }: { rating: number }) => (
  <div className="flex items-center gap-1 mb-2">
    {[1, 2, 3, 4, 5].map((star) => (
      <Star 
        key={star} 
        className={cn(
          "w-3 h-3",
          star <= Math.round(rating) ? "text-amber-400 fill-amber-400" : "text-slate-200"
        )} 
      />
    ))}
    <span className="text-[10px] font-bold text-slate-400 ml-1">{rating.toFixed(1)}</span>
  </div>
);

// --- Main App ---

export default function App() {
  const [suppliers, setSuppliers] = useState<Supplier[]>(mockSuppliers);
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [history, setHistory] = useState<PurchaseHistory[]>(mockHistory);
  const [feedback, setFeedback] = useState<CustomerFeedback[]>(mockFeedback);
  
  const [config, setConfig] = useState<SimulationConfig>({
    urgency: Urgency.PLANNED,
    weights: { speed: 0.3, quality: 0.4, cost: 0.3 },
    thresholds: { onTime: 85, rejection: 5, priceDeviation: 10 }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'suppliers' | 'orders' | 'simulation'>('dashboard');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newSupplier, setNewSupplier] = useState({
    name: '',
    contact: '',
    capabilities: '',
    urgencyLevel: Urgency.PLANNED,
    promisedDeliveryDate: '',
    actualDeliveryDate: '',
    priceVariation: '0-100'
  });

  const handleAddSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    const [min, max] = newSupplier.priceVariation.split('-').map(v => Number(v.trim()) || 0);
    const supplier: Supplier = {
      id: `s${suppliers.length + 1}`,
      name: newSupplier.name,
      contact: newSupplier.contact,
      capabilities: newSupplier.capabilities.split(',').map(c => c.trim()),
      maxCapacity: 1000,
      typicalSpeedDays: 5,
      priceRange: { min: min || 0, max: max || 100 },
      urgencyLevel: newSupplier.urgencyLevel as Urgency,
      promisedDeliveryDate: newSupplier.promisedDeliveryDate,
      actualDeliveryDate: newSupplier.actualDeliveryDate
    };
    setSuppliers([...suppliers, supplier]);
    setIsAddModalOpen(false);
    setNewSupplier({
      name: '',
      contact: '',
      capabilities: '',
      urgencyLevel: Urgency.PLANNED,
      promisedDeliveryDate: '',
      actualDeliveryDate: '',
      priceVariation: '0-100'
    });
  };

  const rankedSuppliers = useMemo(() => {
    return getRankedSuppliers(suppliers, orders, history, feedback, config);
  }, [suppliers, orders, history, feedback, config]);

  const filteredSuppliers = useMemo(() => {
    return rankedSuppliers.filter(s => 
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.capabilities.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [rankedSuppliers, searchQuery]);

  const top3 = rankedSuppliers.slice(0, 3);

  const alerts = useMemo(() => {
    const list: string[] = [];
    rankedSuppliers.forEach(s => {
      if (s.metrics.onTimeDeliveryPercent < config.thresholds.onTime) {
        list.push(`${s.name} is below On-Time threshold (${s.metrics.onTimeDeliveryPercent.toFixed(1)}%)`);
      }
      if (s.metrics.rejectionRate > config.thresholds.rejection) {
        list.push(`${s.name} exceeds Rejection threshold (${s.metrics.rejectionRate.toFixed(1)}%)`);
      }
    });
    return list;
  }, [rankedSuppliers, config.thresholds]);

  const chartData = useMemo(() => {
    return rankedSuppliers.map(s => ({
      name: s.name,
      score: s.metrics.finalScore,
      onTime: s.metrics.onTimeDeliveryPercent,
      quality: s.metrics.qualityScore,
      cost: s.metrics.priceEfficiency
    }));
  }, [rankedSuppliers]);

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col fixed h-full z-20">
        <div className="p-8 flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">ProcureAI</h1>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'suppliers', label: 'Suppliers', icon: Users },
            { id: 'orders', label: 'Orders', icon: ShoppingCart },
            { id: 'simulation', label: 'Simulation', icon: Settings2 },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                activeTab === item.id 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" 
                  : "text-slate-400 hover:text-white hover:bg-slate-800"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6">
          <div className="bg-slate-800 rounded-2xl p-4 border border-slate-700">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-slate-300 uppercase">System Alerts</span>
            </div>
            <p className="text-xs text-slate-400 mb-3">
              {alerts.length} critical alerts detected in supplier network.
            </p>
            <button 
              onClick={() => setActiveTab('dashboard')}
              className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-lg transition-colors"
            >
              View All
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 p-8">
        {/* Header */}
        <header className="flex justify-between items-center mb-10">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">
              {activeTab === 'dashboard' && 'Performance Overview'}
              {activeTab === 'suppliers' && 'Supplier Directory'}
              {activeTab === 'orders' && 'Order Management'}
              {activeTab === 'simulation' && 'Scenario Simulation'}
            </h1>
            <p className="text-slate-500 mt-1">
              {format(new Date(), 'EEEE, MMMM do yyyy')}
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                placeholder="Search suppliers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl w-64 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
              />
            </div>
            <button className="p-2.5 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors">
              <Download className="w-5 h-5" />
            </button>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* KPI Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <KpiCard 
                  title="Avg. On-Time Delivery" 
                  value={`${(rankedSuppliers.reduce((acc, s) => acc + s.metrics.onTimeDeliveryPercent, 0) / rankedSuppliers.length).toFixed(1)}%`}
                  icon={Clock}
                  trend={{ val: "4.2%", positive: true }}
                  color="bg-indigo-500"
                />
                <KpiCard 
                  title="Quality Index" 
                  value={`${(rankedSuppliers.reduce((acc, s) => acc + s.metrics.qualityScore, 0) / rankedSuppliers.length).toFixed(1)}/100`}
                  icon={Star}
                  trend={{ val: "1.5%", positive: true }}
                  color="bg-emerald-500"
                />
                <KpiCard 
                  title="Rejection Rate" 
                  value={`${(rankedSuppliers.reduce((acc, s) => acc + s.metrics.rejectionRate, 0) / rankedSuppliers.length).toFixed(2)}%`}
                  icon={XCircle}
                  trend={{ val: "0.8%", positive: false }}
                  color="bg-rose-500"
                />
                <KpiCard 
                  title="Cost Efficiency" 
                  value={`${(rankedSuppliers.reduce((acc, s) => acc + s.metrics.priceEfficiency, 0) / rankedSuppliers.length).toFixed(1)}%`}
                  icon={DollarSign}
                  trend={{ val: "2.1%", positive: true }}
                  color="bg-amber-500"
                />
              </div>

              {/* Recommendation Engine */}
              <div className="bg-slate-900 rounded-3xl p-8 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                  <TrendingUp className="w-64 h-64" />
                </div>
                
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-indigo-500 rounded-lg">
                      <Zap className="w-5 h-5 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold">Top 3 Recommendations</h2>
                    <div className="ml-auto flex gap-2">
                      {Object.values(Urgency).map((u) => (
                        <button
                          key={u}
                          onClick={() => setConfig({ ...config, urgency: u })}
                          className={cn(
                            "px-4 py-1.5 rounded-full text-xs font-bold transition-all",
                            config.urgency === u 
                              ? "bg-white text-slate-900" 
                              : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                          )}
                        >
                          {u}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {top3.map((s, idx) => (
                      <div key={s.id} className={cn(
                        "p-6 rounded-2xl border transition-all hover:scale-[1.02]",
                        idx === 0 ? "bg-indigo-600/20 border-indigo-500/50" : "bg-slate-800/50 border-slate-700"
                      )}>
                        <div className="flex justify-between items-start mb-4">
                          <div className={cn(
                            "w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg",
                            idx === 0 ? "bg-indigo-50 text-white" : "bg-slate-700 text-slate-300"
                          )}>
                            {idx + 1}
                          </div>
                          <RecommendationBadge rank={idx + 1} />
                        </div>
                        <h3 className="text-xl font-bold mb-1">{s.name}</h3>
                        <p className="text-slate-400 text-sm mb-4">{s.capabilities.join(', ')}</p>
                        
                        <div className="space-y-4">
                          <div className="flex justify-between items-end">
                            <span className="text-slate-400 text-xs uppercase font-bold tracking-wider">Final Score</span>
                            <span className="text-2xl font-black text-white">{s.metrics.finalScore.toFixed(1)}</span>
                          </div>
                          <div className="h-2 w-full bg-slate-700 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${s.metrics.finalScore}%` }}
                              className={cn("h-full", idx === 0 ? "bg-indigo-500" : "bg-emerald-500")}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Charts & Alerts */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                  <SectionHeader 
                    title="Supplier Performance Matrix" 
                    subtitle="Comparative analysis of top suppliers across key metrics"
                  />
                  <div className="h-[350px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 10 }} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff' }}
                          itemStyle={{ color: '#fff' }}
                        />
                        <Bar dataKey="onTime" fill="#6366f1" radius={[4, 4, 0, 0]} name="On-Time %" />
                        <Bar dataKey="quality" fill="#10b981" radius={[4, 4, 0, 0]} name="Quality Score" />
                        <Bar dataKey="cost" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Cost Efficiency" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                  <SectionHeader title="Risk Alerts" subtitle="Threshold violations" />
                  <div className="space-y-4">
                    {alerts.length > 0 ? alerts.map((alert, idx) => (
                      <div key={idx} className="flex gap-3 p-4 bg-rose-50 border border-rose-100 rounded-2xl text-rose-700">
                        <AlertTriangle className="w-5 h-5 shrink-0" />
                        <p className="text-sm font-medium">{alert}</p>
                      </div>
                    )) : (
                      <div className="flex flex-col items-center justify-center py-12 text-slate-400">
                        <CheckCircle2 className="w-12 h-12 mb-2 text-emerald-500" />
                        <p className="font-medium">All suppliers within limits</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* System Flowchart */}
              <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                <SectionHeader title="System Processing Flow" subtitle="Data pipeline from input to final ranking" />
                <div className="flex flex-col md:flex-row items-center justify-between gap-4 py-8">
                  {[
                    { label: 'Data Input', sub: 'Master, Orders, History', icon: ShoppingCart, color: 'bg-indigo-500' },
                    { label: 'Preprocessing', sub: 'Normalization & Filtering', icon: Settings2, color: 'bg-slate-500' },
                    { label: 'Metric Calc', sub: 'On-Time, Quality, Cost', icon: TrendingUp, color: 'bg-amber-500' },
                    { label: 'Final Scoring', sub: 'Urgency Weighted Logic', icon: Zap, color: 'bg-emerald-500' },
                    { label: 'Ranking', sub: 'Dynamic Dashboard', icon: LayoutDashboard, color: 'bg-indigo-600' },
                  ].map((step, idx, arr) => (
                    <React.Fragment key={idx}>
                      <div className="flex flex-col items-center text-center w-full max-w-[150px]">
                        <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center mb-3 shadow-lg", step.color)}>
                          <step.icon className="w-6 h-6 text-white" />
                        </div>
                        <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">{step.label}</h4>
                        <p className="text-[10px] text-slate-500 mt-1">{step.sub}</p>
                      </div>
                      {idx < arr.length - 1 && (
                        <div className="hidden md:block">
                          <ChevronRight className="w-5 h-5 text-slate-300" />
                        </div>
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'suppliers' && (
            <motion.div 
              key="suppliers"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden"
            >
              <div className="p-8 border-bottom border-slate-100 flex justify-between items-center">
                <SectionHeader title="Supplier Ranking" subtitle="Sortable list of all suppliers based on current urgency" />
                <div className="flex gap-2">
                  <button 
                    onClick={() => setIsAddModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-600/20"
                  >
                    <Plus className="w-4 h-4" />
                    Add Supplier
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-y border-slate-100">
                      <th className="px-8 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Rank</th>
                      <th className="px-8 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Supplier</th>
                      <th className="px-8 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Urgency</th>
                      <th className="px-8 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Price Range</th>
                      <th className="px-8 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Delivery (P vs A)</th>
                      <th className="px-8 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Capabilities</th>
                      <th className="px-8 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Performance Metrics</th>
                      <th className="px-8 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Final Score</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredSuppliers.map((s) => (
                      <tr key={s.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors group">
                        <td className="px-8 py-6">
                          <div className={cn(
                            "w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm",
                            s.metrics.rank === 1 ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600"
                          )}>
                            {s.metrics.rank}
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div>
                            <div className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{s.name}</div>
                            <div className="text-xs text-slate-500 mt-1">{s.contact}</div>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <span className={cn(
                            "px-2 py-1 rounded-md text-[10px] font-bold uppercase",
                            s.urgencyLevel === Urgency.IMMEDIATE ? "bg-rose-100 text-rose-700" :
                            s.urgencyLevel === Urgency.PLANNED ? "bg-indigo-100 text-indigo-700" :
                            "bg-slate-100 text-slate-700"
                          )}>
                            {s.urgencyLevel || 'N/A'}
                          </span>
                        </td>
                        <td className="px-8 py-6">
                          <div className="text-xs font-bold text-slate-900">
                            ${s.priceRange.min} - ${s.priceRange.max}
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex flex-col">
                            <span className="text-xs text-slate-400">P: {s.promisedDeliveryDate ? format(parseISO(s.promisedDeliveryDate), 'MMM d, HH:mm') : 'N/A'}</span>
                            <span className={cn(
                              "font-bold text-xs",
                              s.actualDeliveryDate && s.promisedDeliveryDate && parseISO(s.actualDeliveryDate) > parseISO(s.promisedDeliveryDate) ? "text-rose-600" : "text-emerald-600"
                            )}>
                              A: {s.actualDeliveryDate ? format(parseISO(s.actualDeliveryDate), 'MMM d, HH:mm') : 'N/A'}
                            </span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex flex-wrap gap-1">
                            {s.capabilities.map(c => (
                              <span key={c} className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-bold uppercase">
                                {c}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-8 py-6 min-w-[240px]">
                          <RatingStars rating={s.metrics.rating} />
                          <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                            <MetricBar label="On-Time" value={s.metrics.onTimeDeliveryPercent} color="bg-indigo-500" />
                            <MetricBar label="Quality" value={s.metrics.qualityScore} color="bg-emerald-500" />
                            <MetricBar label="Rejection" value={s.metrics.rejectionRate} color="bg-rose-500" />
                            <MetricBar label="Cost Eff." value={s.metrics.priceEfficiency} color="bg-amber-500" />
                          </div>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <div className="inline-flex flex-col items-end">
                            <span className="text-xl font-black text-slate-900">{s.metrics.finalScore.toFixed(1)}</span>
                            <RecommendationBadge rank={s.metrics.rank} />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'simulation' && (
            <motion.div 
              key="simulation"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-8"
            >
              <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                <SectionHeader title="Scenario Configuration" subtitle="Adjust weights and urgency to simulate different procurement needs" />
                
                <div className="space-y-8">
                  <div>
                    <label className="block text-sm font-bold text-slate-900 mb-4 uppercase tracking-wider">Urgency Level</label>
                    <div className="grid grid-cols-3 gap-4">
                      {Object.values(Urgency).map((u) => (
                        <button
                          key={u}
                          onClick={() => setConfig({ ...config, urgency: u })}
                          className={cn(
                            "flex flex-col items-center gap-3 p-6 rounded-2xl border-2 transition-all",
                            config.urgency === u 
                              ? "border-indigo-600 bg-indigo-50 text-indigo-700 shadow-md" 
                              : "border-slate-100 bg-slate-50 text-slate-400 hover:border-slate-200"
                          )}
                        >
                          {u === Urgency.IMMEDIATE && <Zap className="w-8 h-8" />}
                          {u === Urgency.PLANNED && <Calendar className="w-8 h-8" />}
                          {u === Urgency.SCHEDULED && <Clock className="w-8 h-8" />}
                          <span className="font-bold text-sm">{u}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="flex items-center gap-2 mb-4">
                      <TrendingUp className="w-5 h-5 text-indigo-600" />
                      <h3 className="font-bold text-slate-900">Current Formula Logic</h3>
                    </div>
                    <div className="text-sm text-slate-600 font-mono leading-relaxed">
                      {config.urgency === Urgency.IMMEDIATE && (
                        <p>Score = 0.5 * OnTime + 0.3 * Quality - 0.2 * Rejection</p>
                      )}
                      {config.urgency === Urgency.PLANNED && (
                        <p>Score = 0.4 * Quality + 0.3 * OnTime - 0.1 * Rejection + 0.2 * Cost</p>
                      )}
                      {config.urgency === Urgency.SCHEDULED && (
                        <p>Score = 0.3 * Quality + 0.3 * OnTime - 0.1 * Rejection + 0.3 * Cost</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Priority Weights</h3>
                    <p className="text-xs text-slate-500 italic">* Note: Weights are currently fixed per urgency type as per standard operating procedures, but can be overridden in manual mode.</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="p-4 bg-white border border-slate-200 rounded-xl">
                        <div className="text-xs font-bold text-slate-500 mb-1">SPEED</div>
                        <div className="text-xl font-black text-indigo-600">{(config.urgency === Urgency.IMMEDIATE ? 50 : 30)}%</div>
                      </div>
                      <div className="p-4 bg-white border border-slate-200 rounded-xl">
                        <div className="text-xs font-bold text-slate-500 mb-1">QUALITY</div>
                        <div className="text-xl font-black text-emerald-600">{(config.urgency === Urgency.IMMEDIATE ? 30 : 40)}%</div>
                      </div>
                      <div className="p-4 bg-white border border-slate-200 rounded-xl">
                        <div className="text-xs font-bold text-slate-500 mb-1">COST</div>
                        <div className="text-xl font-black text-amber-600">{(config.urgency === Urgency.IMMEDIATE ? 0 : (config.urgency === Urgency.PLANNED ? 20 : 30))}%</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 p-8 rounded-3xl text-white shadow-xl">
                <SectionHeader title="Simulation Results" subtitle="Real-time ranking updates based on scenario" />
                
                <div className="space-y-6">
                  {rankedSuppliers.map((s, idx) => (
                    <motion.div 
                      layout
                      key={s.id} 
                      className={cn(
                        "p-5 rounded-2xl border flex items-center gap-6 transition-all",
                        idx === 0 ? "bg-indigo-600 border-indigo-400 shadow-lg shadow-indigo-600/20" : "bg-slate-800 border-slate-700"
                      )}
                    >
                      <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center font-black text-lg">
                        {idx + 1}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-lg">{s.name}</h4>
                        <div className="flex gap-4 mt-1">
                          <div className="flex items-center gap-1 text-xs text-white/60">
                            <Clock className="w-3 h-3" />
                            {s.metrics.onTimeDeliveryPercent.toFixed(0)}%
                          </div>
                          <div className="flex items-center gap-1 text-xs text-white/60">
                            <Star className="w-3 h-3" />
                            {s.metrics.qualityScore.toFixed(0)}
                          </div>
                          <div className="flex items-center gap-1 text-xs text-white/60">
                            <DollarSign className="w-3 h-3" />
                            {s.metrics.priceEfficiency.toFixed(0)}%
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-black">{s.metrics.finalScore.toFixed(1)}</div>
                        <div className="text-[10px] font-bold uppercase tracking-widest opacity-60">Score</div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-8 p-6 bg-white/5 rounded-2xl border border-white/10">
                  <div className="flex items-center gap-2 mb-2 text-amber-400">
                    <TrendingUp className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-wider">AI Insight</span>
                  </div>
                  <p className="text-sm text-slate-300">
                    Based on current <strong>{config.urgency}</strong> parameters, <strong>{rankedSuppliers[0].name}</strong> is the optimal choice. They have a {rankedSuppliers[0].metrics.onTimeDeliveryPercent.toFixed(0)}% historical success rate for urgent requests.
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'orders' && (
            <motion.div 
              key="orders"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                <SectionHeader title="Recent Purchase Orders" subtitle="Track proposed vs actual delivery and payments" />
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100">
                        <th className="pb-4">Order ID</th>
                        <th className="pb-4">Supplier</th>
                        <th className="pb-4">Urgency</th>
                        <th className="pb-4">Delivery (P vs A)</th>
                        <th className="pb-4">Price (P vs A)</th>
                        <th className="pb-4">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {history.map((h) => {
                        const order = orders.find(o => o.id === h.orderId);
                        const supplier = suppliers.find(s => s.id === h.supplierId);
                        const isLate = parseISO(h.actualDeliveryDate) > parseISO(h.proposedDeliveryDate);
                        const isOverpaid = h.pricePaid > h.priceAgreed;
                        
                        return (
                          <tr key={h.id} className="text-sm">
                            <td className="py-4 font-medium text-slate-900">{h.orderId}</td>
                            <td className="py-4 text-slate-600">{supplier?.name}</td>
                            <td className="py-4">
                              <span className={cn(
                                "px-2 py-1 rounded-md text-[10px] font-bold uppercase",
                                order?.urgency === Urgency.IMMEDIATE ? "bg-rose-100 text-rose-700" :
                                order?.urgency === Urgency.PLANNED ? "bg-indigo-100 text-indigo-700" :
                                "bg-slate-100 text-slate-700"
                              )}>
                                {order?.urgency}
                              </span>
                            </td>
                            <td className="py-4">
                              <div className="flex flex-col">
                                <span className="text-xs text-slate-400">P: {h.proposedDeliveryDate}</span>
                                <span className={cn("font-bold", isLate ? "text-rose-600" : "text-emerald-600")}>
                                  A: {h.actualDeliveryDate}
                                </span>
                              </div>
                            </td>
                            <td className="py-4">
                              <div className="flex flex-col">
                                <span className="text-xs text-slate-400">P: ${h.priceAgreed}</span>
                                <span className={cn("font-bold", isOverpaid ? "text-rose-600" : "text-emerald-600")}>
                                  A: ${h.pricePaid}
                                </span>
                              </div>
                            </td>
                            <td className="py-4">
                              <div className="flex items-center gap-1.5 text-emerald-600 font-bold">
                                <CheckCircle2 className="w-4 h-4" />
                                Completed
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Add Supplier Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                <h2 className="text-xl font-bold text-slate-900">Add New Supplier</h2>
                <button 
                  onClick={() => setIsAddModalOpen(false)}
                  className="p-2 hover:bg-slate-200 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>
              
              <form onSubmit={handleAddSupplier} className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Supplier Name</label>
                    <input 
                      required
                      type="text" 
                      value={newSupplier.name}
                      onChange={e => setNewSupplier({...newSupplier, name: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                      placeholder="e.g. Global Parts Ltd"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Contact Email</label>
                    <input 
                      required
                      type="email" 
                      value={newSupplier.contact}
                      onChange={e => setNewSupplier({...newSupplier, contact: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                      placeholder="contact@example.com"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Capabilities (comma separated)</label>
                    <input 
                      required
                      type="text" 
                      value={newSupplier.capabilities}
                      onChange={e => setNewSupplier({...newSupplier, capabilities: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                      placeholder="CNC, Milling, Assembly"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Urgency Level</label>
                    <select 
                      value={newSupplier.urgencyLevel}
                      onChange={e => setNewSupplier({...newSupplier, urgencyLevel: e.target.value as Urgency})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                    >
                      {Object.values(Urgency).map(u => (
                        <option key={u} value={u}>{u}</option>
                      ))}
                    </select>
                  </div>
                  <div className="col-span-1">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Promised Delivery</label>
                    <input 
                      type="datetime-local" 
                      value={newSupplier.promisedDeliveryDate}
                      onChange={e => setNewSupplier({...newSupplier, promisedDeliveryDate: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                    />
                  </div>
                  <div className="col-span-1">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Actual Delivery</label>
                    <input 
                      type="datetime-local" 
                      value={newSupplier.actualDeliveryDate}
                      onChange={e => setNewSupplier({...newSupplier, actualDeliveryDate: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Price Variation ($ Min - Max)</label>
                    <input 
                      required
                      type="text" 
                      value={newSupplier.priceVariation}
                      onChange={e => setNewSupplier({...newSupplier, priceVariation: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                      placeholder="e.g. 50-150"
                    />
                  </div>
                </div>
                
                <div className="pt-4 flex gap-3">
                  <button 
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="flex-1 px-4 py-3 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 px-4 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-600/20"
                  >
                    Add Supplier
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
